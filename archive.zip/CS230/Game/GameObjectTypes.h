
#pragma once

enum class GameObjectType {
    Hero,
    Bunny,
    Ball,
    TreeStump,
    Meteor,
    Ship,
    Count,
};

