
#pragma once

enum class Ship_Anim {
    None_Anim,
    Explode_Anim,
};


