/*--------------------------------------------------------------
Copyright (C) 2021 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior
written consent of DigiPen Institute of Technology is prohibited.
File Name: Flame_Anims.h
Project: CS230
Author: Taeju Kwon
Creation date: 3/12/2021
-----------------------------------------------------------------*/

#pragma once 

enum class Flame_Anim {
    None_Anim,
    Flame_Anim,
};

